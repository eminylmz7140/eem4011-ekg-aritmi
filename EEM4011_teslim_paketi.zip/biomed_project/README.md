# EEM4011 Biyomedikal Projesi

**Güncel ana proje, Aşama 2:** [Hasta bazlı V atımı başlangıç deneyi](asama2_v_baseline.md). Hocanın kişisel notuna göre 43 MIT-BIH kaydı, yalnız MLII kanalı, DS1'de eşik seçimi ve DS2'de tek test kullanılır. Çalıştırma: `python 02_download_data.py`, ardından `python 11_phase2_v_baseline.py`. Doğrulanmış başlangıç V-F1 değeri **0,702**'dir (T=0,90). [Colab defteri](EEM4011_Asama2_V_Colab.ipynb) aynı adımları yürütür. Veri dosyalarını depoya yüklemeyin.

Önceki [48 kayıtlı R-tepesi deneyi](asama2_ekg_sinyal_isleme.md) ayrı bir sinyal işleme alıştırmasıdır. Onun 0,8306 ve 0,9805 R-tepesi F1 değerlerini ana projenin **V-F1** alanına yazmayın. Aşağıdaki kNN bölümü vize sonrası genişletmedir; Aşama 2 formunda kullanılmaz.

MIT-BIH Arrhythmia Database üzerinde EKG atımlarını sınıflandıran, hasta sızıntısını azaltan kNN başlangıç projesi.

Teslim için yöntem, literatür, gerçek sonuçlar ve sınırlar [proje.md](proje.md) dosyasında birleştirildi. Proje sorusu aynı hasta bazlı test grubunda basit kNN ile EKG dalga şekli ve RR özellikleri eklenmiş kNN'nin karşılaştırılmasıdır. Literatürde ilk yöntem veya doğrulanmış genel araştırma açığı iddiası yoktur.

## Şekilleri üretme

Gerçek MIT-BIH kayıt 100'ün ilk sekiz saniyesi ve sınıf bazlı F1 karşılaştırması:

```powershell
python 09_make_figures.py --data data --comparison artifacts/improved/comparison.json --output artifacts/figures
```

Bu oturumda tam veriyle üretilen grafikler geçici çıktı klasöründe de doğrulandı. Kaynak veri ve büyük model dosyaları GitHub'a veya forma yüklenmemelidir. `09_make_figures.py` anotasyon işaretlerini otomatik R-tepe tespit sonucu olarak sunmaz.

## Geliştirilmiş sürüm

İlk altı aşama korunur. İsteğe bağlı 7. aşama (`07_improve_model.py`) dalga şeklinden 24 ve RR sürelerinden 6 özellik ekler; dört kNN seçeneğini eğitim hastaları içindeki iki ayrı doğrulama bölmesinde karşılaştırır. Sınıf başına örnek sınırlama yalnızca eğitimde uygulanır. Seçim ölçütü ortalama macro-F1'dır. 8. aşama (`08_verify_improvement.py`) bölmeleri, eğitimde öğrenilen ölçeklemeyi ve tahminlerden hesaplanan metrikleri doğrular.

```powershell
python run_pipeline.py --improve
# Veri daha önce data/ içine indirildiyse:
python run_pipeline.py --local-only --improve
```

Mevcut baseline çıktısı hazırsa yalnızca geliştirme ve kontrol:

```powershell
python 07_improve_model.py --baseline artifacts --output artifacts/improved
python 08_verify_improvement.py --baseline artifacts --output artifacts/improved
```

Çıktı klasöründe `comparison.json`, `results_improved.md`, `predictions.csv`, `model_improved.joblib` ve `features_improved.csv` üretilir. Bu oturumun kayıtlı karşılaştırması `artifacts/results_improved.md` dosyasındadır. İlk 48 kayıtlı deneyde macro-F1 0,3043'ten 0,4261'e yükselmiş; accuracy 0,7637'den 0,7450'ye düşmüştür. S ve Q sınıfları iyileşmiş, F sınıfı başarısız kalmıştır.

Sınırlar: Bu, önceden raporlanan aynı test grubunda bir geliştirme karşılaştırmasıdır; bağımsız dış doğrulama değildir. Referans anotasyonlardaki atım konumları kullanılır; otomatik R-tepe tespit başarısı ölçülmez. Sonraki RR özelliği bir sonraki atımın görülmesini gerektirir; dolayısıyla yöntem çevrimdışıdır. Küçük iki kayıtlık yazılım denemesi iç doğrulama için yeterli değildir.

## Altı aşama

1. `01_environment.py` bağımlılıkları ve sürümleri kontrol eder.
2. `02_download_data.py` PhysioNet'in tam ZIP arşivini indirir, bütünlüğünü kontrol eder ve 48 kaydı açar. Yarım kalan indirme yeniden çalıştırınca kaldığı yerden sürer.
3. `03_read_records.py` indirilen kayıtları ve anotasyonları okur, temiz bir atım tablosu üretir.
4. `04_extract_features.py` her atımdan istatistiksel özellikler çıkarır. Kanal varsa MLII, yoksa II, son çare olarak ilk kanal seçilir.
5. `05_split_and_model.py` kayıt gruplarını eğitim/test olarak ayırır ve kNN modelini eğitir.
6. `06_evaluate.py` accuracy, macro-F1, sınıf bazlı rapor ve karmaşıklık matrisini kaydeder.

`run_pipeline.py` aşamaları sırayla çalıştırır. Tam proje varsayılan olarak tüm kayıtları kullanır:

```powershell
python -m pip install -r requirements.txt
python run_pipeline.py
```

Kısa bir yazılım denemesi için `python run_pipeline.py --records 100 101` kullanılabilir. İki kayıtlık bu alt küme yalnızca kod akışını kontrol eder; proje sonucunu veya genellenebilir performansı temsil etmez.

Google Colab'da proje klasörüne geçtikten sonra:

```python
!pip install -r requirements.txt
!python run_pipeline.py
```

İlk tam çalıştırma 73,5 MB'lık arşivi indirir ve açar; süre ağ hızına bağlıdır. Çalışma kesilirse aynı komutu yeniden çalıştırın; kısmi arşivden sürdürür.

Pipeline çalışınca ayrıntılı çıktılar `artifacts/` altında oluşur. Bu ortamda tam veriyle doğruladığım çalıştırmanın özet ve metrikleri de `artifacts/results_full_dataset.md` ve `artifacts/metrics_full_dataset.json` dosyalarındadır.

Not: Proje, `EEM4011_DATA_DIR` ve `EEM4011_ARTIFACTS_DIR` ortam değişkenleriyle veri/çıktı klasörlerini değiştirmeyi destekler. PhysioNet erişimi olmayan bilgisayarda Colab'da çalıştırın veya MIT-BIH `.hea`, `.dat`, `.atr` dosyalarını `data/` klasörüne koyup `python run_pipeline.py --local-only` komutunu kullanın. Eksik indirme olursa pipeline durur; yeniden çalıştırmak tamamlanmamış dosyaları sürdürür.

Hasta ayrımında aynı kişiye ait 201 ve 202 kayıtları tek grupta tutulur. Diğer MIT-BIH kayıtları farklı kişilerden gelir. Veri kaynağı: [PhysioNet MIT-BIH Arrhythmia Database](https://physionet.org/content/mitdb/1.0.0/) (DOI: 10.13026/C2F305). Raporunuzun kaynakçasında veri kümesiyle birlikte PhysioNet'in önerdiği özgün makaleyi kullanın: Moody ve Mark, “The impact of the MIT-BIH Arrhythmia Database,” IEEE Engineering in Medicine and Biology Magazine, 20(3), 45–50, 2001.

## Yöntem kapsamı ve yorum

Etiketler AAMI EC57 sınıflarına dayalı bir eşlemedir: N, S, V, F ve Q. Bu eğitim projesi veri kümesindeki 48 kaydı kullanır; pacing içeren kayıtları özel olarak dışlamaz. Bu nedenle değerlendirme AAMI sınıflarından esinlenen bir ders projesidir, resmi/katı EC57 benchmark sonucu olarak sunulmamalıdır. Baseline model tek bir EKG kanalından ham pencere üzerinde altı basit istatistiksel özellik çıkarır ve k=5 ağırlıklı kNN kullanır; filtreleme, özellik seçimi veya hiperparametre araması yapmaz.

Özellikle iki kayıtlık deneme, azınlık sınıflarını test kümesinde hiç içermeyebilir. Accuracy tek başına yeterli değildir; macro-F1, sınıf destek sayıları, sınıf bazlı precision/recall ve karmaşıklık matrisi birlikte yorumlanmalıdır. Sonuç dosyası `artifacts/metrics.json` içindedir. Tam veri seti ve hasta bazlı ayrımla yeniden çalıştırılmadan sonuçlar nihai proje bulgusu olarak raporlanmamalıdır.
